SAVANNA BREW CAFE WEBSITE

CONTENTS
- index.html: Home
- about.html: About Us
- menu.html: Menu and prices
- gallery.html: Eight-image gallery
- contact.html: Contact details, opening hours and reservation form
- css/style.css: Shared external stylesheet
- images/: Local logo and image assets

HOW TO VIEW
1. Extract this ZIP file.
2. Open the savanna-brew folder.
3. Double-click index.html.
4. Use the navigation links to visit all five pages.

NOTES
- Built with HTML5 and external CSS only. No JavaScript or frameworks.
- The form uses a mailto action. It opens the visitor's email application; it does not store bookings or automatically confirm reservations.
- Image files are illustrative local placeholders. Replace them with approved café photographs if required.
- Google Fonts are optional; fallback fonts are included.

VALIDATION
Before submission, validate all HTML pages at https://validator.w3.org/ and CSS at https://jigsaw.w3.org/css-validator/.
Validation has not been independently performed during generation. Record any remaining warnings here after testing.
